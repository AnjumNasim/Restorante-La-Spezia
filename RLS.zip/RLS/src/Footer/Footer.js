import { Container, Row } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import Comp from './comp';
import './footer.css'


function Footer(props) {
    return (
        <>
            <Card className='footerCard'>
                <Container className='footerContainer' >
                    <Row className='footerRow'>

                        <Comp className='footerCol1' text='Company' 
                        href1='/about' text1='About Us' 
                        href2='./contact' text2='Contact Us'
                         href3='./bookmytable' text3='Reservation' />

                        <Comp className='footerCol2' text='Contact'
                         href1='https://www.google.com/maps/search/spezia+spezia/@22.554075,88.237154,13z?hl=en'
                          text1='Via dei Mille, 76, 19121 La Spezia SP, Italy'
                           text2='+012 345 67890' href3='https://www.gmail.com'
                            text3='info@example.com' />

                        <Comp className='footerCol3' text='Opening'
                         text1='Monday - Sunday' text2='09AM - 09PM'
                          text3='Sunday 10 AM-08 PM' />

                        <Comp className='footerCol4' text='Newsletter' 
                        text1='Dolor amet sit justo amet elitr clita ipsum elitr est.' />
                    </Row>
                    <Card.Footer className="text-muted">
                            <p>© Your Site Name, All Right Reserved. Designed By HTML Codex</p>
                            <p>Distributed By ThemeWagon</p>
                        </Card.Footer>
                </Container>
            </Card>
        </>
    )
}

export default Footer;









