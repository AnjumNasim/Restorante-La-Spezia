import { Col } from 'react-bootstrap';
import './footer.css'
import { Outlet } from 'react-router-dom';


function Comp(props) {
    return (
        <>
            <Col className={props.className}>
                <h1 className='propsH1'>{props.text}</h1><br />
              <a href={props.href1} className='propsA1'> {props.text1}</a><br/>
                <a href={props.href2} className='propsA1'>{props.text2}</a><br />
                <a href={props.href3} className='propsA1'>{props.text3}</a><br />
                <p className='propsP'>{props.text4}</p><br />
                <p className='propsP'>{props.text5}</p>
            </Col>
            <Outlet/>
        </>
    )
}
export default Comp;




