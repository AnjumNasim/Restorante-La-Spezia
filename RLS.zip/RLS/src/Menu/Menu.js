import { Container, Row, Col, Button } from "react-bootstrap";
import './menu.css';
import { useEffect, useState } from "react";

// Tabs from React Bootstrap
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

// Material UI Card //
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

import Image from '../pictures/myteamsPictures/3.jpg'







function Menu() {

    const [users, setUsers] = useState([])

    const getUser1 = async () => {
        const response = await fetch('http://localhost:3000/MenuDetails', {
            method: 'POST'
        }).then(response => response.json())
        setUsers(response.data);
    }




    useEffect(() => {
        getUser1();
    }, []);


    return (
        <>
            <Container className="menuContainer">
                <Row className='menuRow'>
                    <Col className="menuCol ">
                        <h1>Menu</h1><br />
                        <h3>Our Food & Beverage Menu</h3>
                        <div>
                            <Tabs
                                defaultActiveKey="profile"

                                
                                id="fill-tab-example"
                                className="mb-3"
                                fill   
                            >
                                <Tab eventKey="home" title="Breakfast">
                                    Tab content for Home
                                </Tab>
                                <Tab eventKey="profile" title="Lunch" style={{fontStyle:'italic', fontFamily: 'PensumPro-BookItalic'}}>
                                    Tab content for Profile
                                </Tab>
                                <Tab eventKey="longer-tab" title="Dinner" style={{fontStyle:'italic', fontFamily: 'PensumPro-BookItalic'}}>
                                    Tab content for Loooonger Tab
                                </Tab>
                            </Tabs>
                        </div>

                        {/* <div className="menuButtons mt-5 d-flex justify-content-around" style={{}}>

                            <Button className="breakfastButton" variant="outline-danger" style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                Breakfast
                            </Button>

                            <Button className="breakfastButton" variant="outline-danger" style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                Lunch
                            </Button>

                            <Button className="breakfastButton" variant="outline-danger" style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                Dinner
                            </Button>
                        </div> */}

                        {
                            users.map((curEle) => {
                                return (
                                    <>
                                        <Col sm={3} style={{ marginTop: '25px', marginBottom: '25px' }} >
                                            <Card>
                                                <CardActionArea>
                                                    <CardMedia
                                                        component="img"
                                                        height="200"
                                                        image={Image}
                                                        alt="Item Image"
                                                    />
                                                    <CardContent style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                                        <Typography gutterBottom variant="h5" component="div">
                                                            {curEle.Breakfast}
                                                        </Typography>

                                                        <Typography variant="body2" color="text.secondary">
                                                            Some quick example text to build on the card title and make up the bulk of the card's content.
                                                        </Typography>

                                                        <Typography gutterBottom variant="h6" component="div">
                                                            $ 115
                                                        </Typography>
                                                    </CardContent>
                                                </CardActionArea>
                                            </Card>
                                        </Col>
                                    </>
                                )
                            })
                        }

                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Menu;








