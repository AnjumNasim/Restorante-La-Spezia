import { Container, Row, Col } from "react-bootstrap";
import './service.css';
import ServiceComp from '../Service/propsService'


function Service() {
    return (
        <>
            <Container className="serviceContain">
                <Row className="serviceRow2">
                    <Col className="serviceCol2">
                        <h1>Our Service</h1>
                        <h3>Explore the services we are providing</h3>
                    </Col>
                </Row>

                <Row className="serviceRow " style={{paddingBottom: '250px'}}>
                    <ServiceComp className1='serviceCol1 mb-4'
                        className2='fa fa-5x fa-utensils text-info mb-4'
                        text1='Quality Food'
                        text2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                    />
                    <ServiceComp className1='serviceCol1 mb-4'
                        className2='fa fa-5x fa-headset text-secondary mb-4'
                        text1='24/7 Service'
                        text2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                    />
                    <ServiceComp className1='serviceCol1 mb-4'
                        className2='fa fa-5x fa-cart-shopping text-success mb-4'
                        text1='Online Order'
                        text2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                    />
                    <ServiceComp className1='serviceCol1 mb-4'
                        className2='fa fa-5x fa-user-tie text-primary mb-4'
                        text1='Master Chefs'
                        text2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                        to='/myteam'
                    />
                </Row>
            </Container>
        </>
    )
}

export default Service;









