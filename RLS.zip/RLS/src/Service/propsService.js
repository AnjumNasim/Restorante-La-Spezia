import { Col } from "react-bootstrap";
import { Link } from "react-router-dom";


function ServiceComp(props) {
    return (
        <Col sm={3} className={props.className1}>
            <Link to={props.to} style={{ textDecoration: 'none', color: 'black' }}>
                <div >
                    <i className={props.className2}></i>
                    <h3>{props.text1}</h3>
                    <p>{props.text2}</p>
                </div>
            </Link>
        </Col>
    )
}

export default ServiceComp;