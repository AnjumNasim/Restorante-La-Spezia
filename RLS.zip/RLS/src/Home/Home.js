import './home.css'
import Button from 'react-bootstrap/Button';
import { Outlet, Link } from "react-router-dom";
import { Container, Row, Col } from 'react-bootstrap';
import Image from '../../src/pictures/image2.jpg'
import Image2 from '../pictures/aboutPictures/img5.jpg'
import Image3 from '../pictures/aboutPictures/img1.jpg'


// Carousel from React
import Carousel from 'react-bootstrap/Carousel';




function Home() {
  return (
    <>
      <Container className="homeContainer container">
        <Row className='homeRow1 row' >
          <Col className='homeColumn1' >

            <div className='homeDivColumn1'>
              <h2> Enjoy Our Delicious Meal</h2><br />
              <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
              <Link to='./bookmytable'> <Button variant="info" className='navbarButton' >Book My Table</Button></Link>
            </div>

          </Col>
          <Col className='homeColumn2' >

            <div className='homeDivColumn2'>
              <div>
                <h2>Restaurante La Spezia</h2><br />
                <HomeCarousel />
              </div>
            </div>

          </Col>
        </Row><br /><br /><br /><br /><br /><br /><br /><br /><br />


        <Row className='homeRow2 row' >
          <Col className='homeColumn3 col-3' >
            <Link className='homeColumn3Link' to="/service">
              <div>
                <i className="fa-solid fa-globe fa-spin fa-spin-reverse fa-6x" ></i><br /><br />
                <h1>24/7 Service</h1>
                <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
              </div>
            </Link>
          </Col>
          <Outlet />


          <Col className='homeColumn4 col-3' >
            <Link className='homeColumn3Link' to="/menu">
              <div>
                <i class="fa-solid fa-utensils fa-flip fa-6x"></i><br /><br />
                <h1>Quality Food</h1>
                <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
              </div>
            </Link>
          </Col>


          <Col className='homeColumn5 col-3' >
            <Link className='homeColumn3Link' to="/menu">
              <div>
                <i class="fa-solid fa-cart-shopping fa-fade fa-6x"></i><br /><br />
                <h1>Online Order</h1>
                <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
              </div>
            </Link>
          </Col>
        </Row>
      </Container>

    </>
  )
}

export default Home;













// Carousel 



function HomeCarousel() {
  return (
    <Carousel className='homeCarousel'>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Image}
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>Morning View</h3>

        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Image2}
          alt="Second slide"
        />

        <Carousel.Caption>
          <h3>Evening View</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Image3}
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3>Dawn View</h3>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}











/* ℛℯ𝓈𝓉𝒶𝓊𝓇𝒶𝓃𝓉ℯ ℒ𝒶 𝒮𝓅ℯ𝓏𝒾𝒶 */