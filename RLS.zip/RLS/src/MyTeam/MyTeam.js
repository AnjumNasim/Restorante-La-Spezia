import { Container, Row, Col } from "react-bootstrap";
import './myteam.css'
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import Image3 from '../pictures/myteamsPictures/3.jpg'
import { useEffect, useState } from "react";




export default function MyTeam() {

    const [user, setUser] = useState([])
    const getUsers = async () => {

        const response = await fetch('http://localhost:3000/selectEmpDetails',{
            method: 'GET'
        }).then(response => response.json());
        setUser(response.data);
    }

    useEffect(() => {
        getUsers();
    }, []);

    return (
        <>
            <Container className="myteamContainer">
                <Row className="myteamRow">
                    <h1 className="myteamH1 my-3">My Teams</h1>
                        {
                            user.map((ce) => {
                                return (
                                    <Col sm={3} style={{marginTop:'20px', marginBottom:'20px'}}>
                                        <Card style={{ width: '100%' }} className='myteamCard'>
                                            <Card.Img variant="top" src={Image3} />
                                            <Card.Body>
                                                <Card.Title>
                                                    <h4 style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>{ce.emp_name}</h4>
                                                </Card.Title>
                                                <Card.Text style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                                    {ce.emp_designation}
                                                </Card.Text>
                                            </Card.Body>
                                            <ListGroup className="list-group-flush">
                                                <ListGroup.Item style={{ fontFamily: 'PensumPro-BookItalic', fontStyle: 'italic' }}>
                                                    {ce.emp_age}
                                                </ListGroup.Item>
                                            </ListGroup>
                                        </Card>
                                    </Col>
                                )
                            })
                        }
                </Row>
            </Container>
        </>
    )
}















