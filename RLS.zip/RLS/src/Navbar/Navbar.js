
import 'bootstrap/dist/css/bootstrap.min.css';
import './navbar.css';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link, Outlet } from 'react-router-dom';
import BookMyTable from '../BookMyTable/BookMyTable';


function Navbar1() {
  return (
    <>
      {/* <Navbar className='navbar1 sticky-top shadow-sm' expand="lg">
        <Container className='navbarContainer' >
          <Navbar.Brand href="#">
            <h1 className='navbarH1' >Restorante La Spezia</h1>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
              <div className='navbarHead'>
                <Nav.Link href="/">HOME</Nav.Link>
                <Nav.Link href="/about">ABOUT</Nav.Link>
                <Nav.Link href="/service">SERVICE</Nav.Link>
                <Nav.Link href="/menu">MENU</Nav.Link>
                <NavDropdown title="PAGES" id="navbarScrollingDropdown">
                  <NavDropdown.Item href="/myteam">MY TEAM</NavDropdown.Item>
                  <NavDropdown.Item href="/testimonial"> TESTIMONIAL</NavDropdown.Item>
                </NavDropdown>
                <Nav.Link href="/contact">CONTACT</Nav.Link>
              </div>
            </Nav>
            <Form className="d-flex">
              <Link to='bookmytable'>
              <Button variant="outline-success" className='navbarButton' onClick={BookMyTable}>BOOK MY TABLE</Button>
              </Link>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar> */}

      <Navbar style={{backgroundColor:'rgb(175, 212, 190)'}} expand="lg" >
        <Container>
          <Row style={{ width: '100%', marginTop: '20px' }}>
            <Col xs={6}>
              <Navbar.Brand href="#">
                <h1 className='navbarH1' >
                  Restorante La Spezia
                </h1>
              </Navbar.Brand>
            </Col>
            <Col xs={6}>
              <Navbar.Toggle aria-controls="navbarScroll" style={{ float: 'right' }} />

              <Navbar.Collapse id="navbarScroll">
                <Nav
                  className="me-auto my-2 my-lg-0"
                  style={{ maxHeight: '100px', fontWeight: '500', fontSize: '14px' }}
                  navbarScroll
                >
                  <Nav.Link href="/">HOME</Nav.Link>
                  <Nav.Link href="/about">ABOUT</Nav.Link>
                  <Nav.Link href="/service">SERVICE</Nav.Link>
                  <Nav.Link href="/menu">MENU</Nav.Link>
                  <NavDropdown title="PAGES" id="navbarScrollingDropdown">
                    <NavDropdown.Item href="/myteam">MY TEAM</NavDropdown.Item>
                    <NavDropdown.Item href="/testimonial"> TESTIMONIAL</NavDropdown.Item>
                  </NavDropdown>
                  <Nav.Link href="/contact">CONTACT</Nav.Link>
                </Nav>
                
                <Link to='bookmytable'>
                  <Button variant="outline-success" className='navbarButton' onClick={BookMyTable}>BOOK MY TABLE</Button>
                </Link>
                
              </Navbar.Collapse>
            </Col>
          </Row>
        </Container>
      </Navbar>
      <Outlet />
    </>
  )
}

export default Navbar1;
