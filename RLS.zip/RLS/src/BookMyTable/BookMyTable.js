import { Container, Row, Col, Form } from "react-bootstrap";
import './bookmytable.css';
import Button from 'react-bootstrap/Button';
import React, { useState } from "react";
// import Box from '@mui/material/Box';
// import Modal from '@mui/material/Modal';






function BookMyTable() {
    return (
        <>
            <Container className="tableContainer">
                <Row className="tableRow1">
                    <Col className="tableCol1">
                        <h1>Reservation</h1>
                        <h3>Table Bookings</h3>
                    </Col>
                </Row>
                <Row className="tableRow2">
                    <Col className="tableCol2">
                        <div className="tableColDiv">
                            <BasicExample />
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )

}

export default BookMyTable;


function BasicExample() {

    const [full_name, setFullname] = useState('');
    const [e_mail, setEmail] = useState('');
    const [contact_no, setContact] = useState('');
    const [no_of_people, setPax] = useState('');
    const [table_no, setTable] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');


    async function Submit(e) {
        let user = { full_name, e_mail, contact_no, no_of_people, table_no, date, time }
        console.warn(user);

        let result = await fetch('http://localhost:3000/saveinsertTable', {
            method: 'POST',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
        })


        result = await result.json();
        console.warn('result', result);

    }




    return (
        <Form method="POST" className="formBasic">
            <div className="mb-4 formFields1" style={{}}>

                <Form.Control className="mb-4 formBasicFields" value={full_name} onChange={(e) => setFullname(e.target.value)}
                    type="full_name" placeholder="Full Name"
                    style={{ width: 400, textAlign: 'center', display: 'flex', margin: 'auto' }} />

                <Form.Control className="formBasicFields" type="email" value={e_mail} onChange={(e) => setEmail(e.target.value)}
                    placeholder="E-Mail"
                    style={{ width: 300, display: 'flex', margin: 'auto', textAlign: 'center' }} />
            </div>


            <Form.Control className="mb-4 formBasicFields" value={contact_no} onChange={(e) => setContact(e.target.value)}
                type="phone" placeholder="Contact No"
                style={{ width: 300, display: 'flex', margin: 'auto', textAlign: 'center' }} />


            <div className="mb-4 formFields2" style={{ display: 'flex', justifyContent: 'center' }}>

                <Form.Control className="formBasicFields" value={no_of_people} onChange={(e) => setPax(e.target.value)}
                    type="number" placeholder="No. of Pax"
                    style={{ width: 110, textAlign: 'center' }} />

                <Form.Control className="formBasicFields" value={table_no} onChange={(e) => setTable(e.target.value)}
                    type="number" placeholder="Table No."
                    style={{ width: 110, marginLeft: '80px', textAlign: 'center' }} />

            </div>


            <div className="mb-4 formFields3" style={{ display: 'flex', justifyContent: 'center' }}>

                <Form.Control className="formBasicFields" value={date} onChange={(e) => setDate(e.target.value)}
                    type="date" placeholder="Date"
                    style={{ width: 130, textAlign: 'center' }} />

                <Form.Control className="formBasicFields" value={time} onChange={(e) => setTime(e.target.value)}
                    type="time" placeholder="Time"
                    style={{ width: 130, marginLeft: '40px', textAlign: 'center' }} />

            </div>
            <div>
                <Button className="formBasicButton" onClick={Submit}
                    variant="warning" type="button"
                    style={{ margin: 'auto', display: 'flex' }}>
                    Submit
                </Button>


            </div>
        </Form >
    );
}



