import Navbar1 from '../src/Navbar/Navbar'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home/Home";
import Footer from "./Footer/Footer";
import About from "./About/About";
import Service from "./Service/Service";
import Menu from './Menu/Menu'
import BookMyTable from './BookMyTable/BookMyTable';
import Testimonial from './Testimonial/Testimonial';
import MyTeam from './MyTeam/MyTeam';
import Contact from './Contact/Contact';



function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navbar1 />}>
            <Route index element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="service" element={<Service />} />
            <Route path="menu" element={<Menu />} />
            <Route path="bookmytable" element={<BookMyTable />} />  
            <Route path="testimonial" element={<Testimonial />} />
            <Route path="myteam" element={<MyTeam />} />   
            <Route path="contact" element={<Contact />} />         
          </Route>
        </Routes>
      </BrowserRouter>
      <Footer />
    </>
  )
}

export default App;




