import { Container, Row, Col, Button } from "react-bootstrap";
import './about.css';

import QuiltedImageList from './AboutImageList';


function About() {
    return (
        <>
            <Container className='aboutContainer'>
                <Row className='aboutRow row'>
                    <Col className='aboutCol1 col-8'>
                        <div className="quiltedImage1Div">
                            <div className="my-5">
                                <QuiltedImageList className='quiltedImage' />
                            </div>

                        </div>
                    </Col>
                    <Col className='aboutCol2 col-4'>
                        <div className="aboutCol2Div" >
                            <h1>About</h1>
                            <h3>History of Restorante La Spezia</h3>
                            <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos erat ipsum et lorem et sit, sed stet lorem sit.

                                Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat ametf</p>
                            <h2 >15 Years of experience</h2>
                            <Button className="aboutCol2Button" variant="warning">Read More</Button>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    );
}

export default About;