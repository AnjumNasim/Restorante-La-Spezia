import { Container, Row, Col, Button } from "react-bootstrap"
import './contact.css';
import Form from 'react-bootstrap/Form';
import { useState } from "react";

// import GMap from '../Contact/googleMap';
import GMap from "./googleMap";

// Material UI
import { Rating } from "@mui/material";





function Contact() {


    return (
        <>
            <Container className="contactContainer">
                <Row className="contactRow1">
                    <Col className="contactCol">
                        <h1>Restorante La Spezia</h1>
                        <h3>We are here to help you</h3>
                    </Col>
                </Row>

                <Row className="contactRow2">
                    <Col className="contactCol2" sm={4}>
                        <div className="mapDivContact">
                            <h2>Google Map</h2>
                            <GMap /><br /><br />
                            <div className="addressPhoneContactAP">
                                <a>Address: Via dei Mille, 76, 19121 La Spezia SP, Italy</a><br />
                                <a>Telephone:  +39 0187 021348</a><br />
                            </div>
                            <div className="iconsContact">
                                <a href='http://www.facebook.com'>
                                    <i className="SMiconsContact fa-brands text-primary fa-facebook fa-3x"></i>
                                </a>
                                <a href="http://www.instagram.com">
                                    <i className="SMiconsContact fa-brands text-danger fa-instagram  fa-3x" ></i>
                                </a>
                                <a href="http://www.snapchat.com">
                                    <i className="SMiconsContact fa-brands text-warning fa-square-snapchat fa-3x"></i>
                                </a>
                                <a href="http://www.linkedin.com">
                                    <i className="SMiconsContact fa-brands text-info fa-linkedin fa-3x"></i>
                                </a>
                            </div>
                        </div>
                    </Col>

                    <Col className="contactCol3" sm={6}>
                        <h2>Contact Us</h2>
                        <ContactForm /><br />
                        <div className="contactCol3Address">
                            Email:<a href="http://www.gmail.com"> restorantelaspezia.gmail.com</a><br />
                        </div>
                        <div className="reviewContact">
                            <h3>Your Precious Review</h3>
                            <RatingComp />
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Contact;











/// Contact Us Form -

function ContactForm() {

    const [user, setUser] = useState({
        name: '', email:'', message:'', ratings:''
    })

    let name, value;

    function SendContact (e){
        name = e.target.name;
        value = e.target.value
        setUser({...user,[name]:value})
    }

    async function SendContactData (){
        let res = await fetch('http://localhost:3000/SaveinsertData', {
            method: 'POST',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
        }) 
        


        
        res = await res.json();
        console.warn('result', res);  

    }

    return (
        <>
            <Form>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>Full Name</Form.Label>
                    <Form.Control value={user.name} onChange={SendContact} name="name" type="text" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control value={user.email} onChange={SendContact} name="email" type="email" placeholder="name@example.com" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                    <Form.Label>Message</Form.Label>
                    <Form.Control value={user.message} onChange={SendContact} name="message" as="textarea" rows={3} />
                </Form.Group>
                <Button onClick={SendContactData} className="contactFormButton" variant="info">Submit</Button>
            </Form>
        </>
    )
}











// Rating Box Material UI

function RatingComp() {
    return (
        <>
            <Rating name="size-large" defaultValue={5} size="large" />
        </>
    )
}











