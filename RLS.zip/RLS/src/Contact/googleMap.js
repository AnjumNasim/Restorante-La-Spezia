



// Google Map integration

function GMap() {
    return (
        <>
            <iframe width="100%" height="400"
                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
                id="gmap_canvas"
                src="https://maps.google.com/maps?width=520&amp;height=400&amp;hl=en&amp;q=spezia%20spezia+(Restorante%20La%20Spezia%20)&amp;t=&amp;z=12&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
            />
        </>
    )
}

export default GMap;

