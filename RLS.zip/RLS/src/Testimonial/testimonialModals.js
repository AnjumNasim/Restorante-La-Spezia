
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';





function TestModal(props) {

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button className='modalButton1' variant="outline-dark" onClick={handleShow}>
      {props.textModalB1}
      </Button>

      <Modal  className={props.classNameModal1} show={show} onHide={handleClose} /*testimonialModal*/
            size="xl"
          
            >

            
        <Modal.Header closeButton>
          <Modal.Title class="modal-title text-center" 
      centered className={props.classNameModal2}>{props.textModal1} </Modal.Title> 
        </Modal.Header>

        
        <Modal.Body>
          <Container className={props.classNameModal3}>
            <Row>
              <Col className={props.classNameModal4}>
                <img src={props.src} alt={props.alt}></img><br /><br />
                <p>{props.textModal2}</p>
              </Col>
            </Row>
          </Container>
        </Modal.Body>


        <Modal.Footer>
          <Button className={props.classNameModal5} variant="secondary" onClick={handleClose}>
          {props.textModalB2}
          </Button>
        </Modal.Footer>

      </Modal>
    </>
  );
}

export default TestModal;