import { Col } from "react-bootstrap";

function TestimonialProp(props) {

    const classes = 'TestimonialProp' + props.className;

    return (
            <Col sm={3} className={props.className1}>
                <div>
                    <i className={props.className2}></i>
                    <h4>{props.text1}</h4>
                    <p>{props.text2}</p>
                    <div className={classes}> {props.children} </div>
                </div>
            </Col>
    )
}

export default TestimonialProp;