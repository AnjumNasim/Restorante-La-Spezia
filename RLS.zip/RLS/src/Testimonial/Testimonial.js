import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import './testimonial.css'
import Carousel from 'react-bootstrap/Carousel';
import TestimonialProp from './propsTestimonial';

import Image from '../pictures/testimonialPictures/awards1.png'
import Image2 from '../pictures/testimonialPictures/JamesBeardMedal.jpg'
import Image3 from '../pictures/testimonialPictures/50BR.jpg'


/* Impoting files of Material UI */
import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import TestModal from './testimonialModals';








function Testimonial() {
    return (
        <>
            <Container className='testimonialContainer' >
                <Row className='testimonialRow'>
                    <Col className='testimonialCol'>
                        <h1> Testimonial </h1>
                        <h3>Awards and Certificates</h3>
                        <Row className='testimonialRowProp'>
                            <TestimonialProp className="modal-title text-center"
                                className1='testimonialPropDiv my-3'
                                className2='fa-solid fa-award fa-4x'
                                text1="World Luxury Restaurant"
                                text2='Worlds Luxury Restaurant Award for 2022 for Best Food & Beverage of the Year'
                            >

                                <TestModal textModalB1='Open' classNameModal1='testimonialModal' classNameModal2='testimonialModalTitle'
                                    centered textModal1='World Luxury Restaurant Award 2022'
                                    classNameModal3='testimonialContainerModal' classNameModal4='testimonialColModal' src={Image} alt='ModalImage'
                                    textModal2='Awarding world-class excellence in hospitality and travel across the globe. World Luxury Restaurant Awards, Port Louis, Mauritius.'
                                    classNameModal5='modalButton2' textModalB2='Close' />

                            </TestimonialProp>

                            <TestimonialProp className1='testimonialPropDiv my-3'
                                className2='fa-solid fa-medal fa-4x'
                                text1='James Beard Medal'
                                text2='James Beard Medal of Honour for year 2020 as the 2nd most popular restaurant in Asia.'
                            >
                                <TestModal textModalB1='Open' classNameModal1='testimonialModal' classNameModal2='testimonialModalTitle'
                                    textModal1='James Beard Medal 2020'
                                    classNameModal3='testimonialContainerModal' classNameModal4='testimonialColModal' src={Image2} alt='ModalImage'
                                    textModal2='Awards by The James Beard Foundation.'
                                    classNameModal5='modalButton2' textModalB2='Close' />


                            </TestimonialProp>

                            <TestimonialProp className1='testimonialPropDiv my-3'
                                className2='fa-solid fa-trophy fa-4x'
                                text1='2022 Food Critic Award'
                                text2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                            >

                                <TestModal textModalB1='Open' classNameModal1='testimonialModal' classNameModal2='testimonialModalTitle' textModal1='2022 Food Critic Award'
                                    classNameModal3='testimonialContainerModal' classNameModal4='testimonialColModal' src={Image} alt='ModalImage'
                                    textModal2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                                    classNameModal5='modalButton2' textModalB2='Close' />

                            </TestimonialProp>

                            <TestimonialProp className1='testimonialPropDiv my-3'
                                className2='fa-solid fa-crown fa-4x'
                                text1='50 Best Restaurant Award'
                                text2='Ranked 5th in 2021 among 50 Best Restaurants in the World'

                            >
                                <TestModal textModalB1='Open' classNameModal1='testimonialModal' classNameModal2='testimonialModalTitle'
                                    textModal1='50 Best Restaurant Award 2021'
                                    classNameModal3='testimonialContainerModal' classNameModal4='testimonialColModal' src={Image3} alt='ModalImage'
                                    textModal2='Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam'
                                    classNameModal5='modalButton2' textModalB2='Close' />

                            </TestimonialProp>

                        </Row>

                        <Row className='testimonialRowRow'>
                            <Col className='testimonialColCol'>
                                <TestimonialCarousel />
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Testimonial;

















function TestimonialCarousel() {
    return (
        <>
            <Carousel className='testimonialCarousel mb-5'>
                <Carousel.Item className='testimonialCarouselItems ' >
                    <div className='testCarouselDiv'>
                        <div className='carouselboxes1'>
                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />

                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />
                        </div>

                        <div className='carouselboxes1'>
                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />

                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />
                        </div>

                        <div className='carouselboxes1'>
                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />

                            <MUIbox text11='Gordon Ramsay'
                                text12='Brunch this weekend?   '
                                text13="I will be in your neighborhood doing errands this…" />
                        </div>
                    </div>
                </Carousel.Item>
            </Carousel>
        </>
    )
}






function MUIbox(props) {
    return (
        <>
            <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                <ListItem alignItems="flex-start">
                    <ListItemAvatar>
                        <Avatar alt="Remy Sharp" src="" />
                    </ListItemAvatar>
                    <ListItemText
                        primary={props.text11}
                        secondary={
                            <React.Fragment>
                                <Typography
                                    sx={{ display: 'inline' }}
                                    component="span"
                                    variant="body2"
                                    color="text.primary"
                                >
                                    {props.text12}
                                </Typography>
                                {props.text13}
                            </React.Fragment>
                        }
                    />
                </ListItem>
            </List>
        </>
    )
}